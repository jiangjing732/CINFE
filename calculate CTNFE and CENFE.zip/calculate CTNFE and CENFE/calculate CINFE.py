# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 16:10:44 2021

@author: zyll1
"""
import numpy as np
import itertools, time
from scipy import stats
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
import copy
import multiprocessing
from multiprocessing import Pool
from scipy.stats import pearsonr
import pandas as pd
import random
# import pingouin
import codecs
import scipy
from scipy import sparse
import scipy.sparse
import os, sys
from timeit import default_timer as timer
from scipy.stats import norm
from scipy.integrate import  quad


def text_save(filename, data):
    file = open(filename, 'w')
    for i in range(len(data)):
        s = str(data[i]).replace('[', '').replace(']', '')
        s = s.replace("'", '').replace(',', '') + '\n'
        file.write(s)
    file.close()

def ind(gene, gene_name):
    xx = [gene_name.index(i) for i in gene]
    return xx

def text(file_name):
    with open(file_name, 'r+') as f:
        line = f.readline()
        while line:
            yield line.split()
            line = f.readline()

def montage(file_name):
    a = []
    for i in text(file_name):
        a.append(i)
    return a


data = pd.read_csv('express_matrix.csv', sep=',', header=None, index_col=0)
all_gene = list(data.index)
print("type(data):", type(data))

# network
f = open('network.txt')
node_center = []
nodes_nei = []
data_matrix = []
while True:
    line = f.readline()
    if len(line) == 0:
        break
    # 去除行尾的换行符并分割字段，同时去除空白字符
    fields = [field.strip() for field in line.rstrip().split('\t')]
    # 检查是否有空字符串字段
    if '' in fields:
        print(f"Line contains empty fields: {line}")
        continue
    try:
        center_g_index = int(fields[0]) - 1
        center_g = all_gene[center_g_index]
    except ValueError:
        print(f"Invalid center gene identifier on line: {line}")
        continue
    nei_g = []
    for g in range(1, len(fields) - 1):
        gene_str = fields[g]
        if gene_str:  # 确保基因标识符不为空或只包含空白字符
            try:
                gene_index = int(gene_str) - 1
                nei_g.append(all_gene[gene_index])
            except ValueError:
                print(f"Invalid neighbor gene identifier '{gene_str}' on line: {line}")
        else:
            print(f"Empty neighbor gene identifier at position {g + 1} on line: {line}")
    # 处理最后一个字段，去除可能的尾随字符
    last_field = fields[-1].strip()
    if last_field:
        try:
            last_gene_index = int(last_field) - 1
            nei_g.append(all_gene[last_gene_index])
        except ValueError:
            print(f"Invalid last gene identifier '{last_field}' on line: {line}")
    else:
        print(f"Empty last gene identifier on line: {line}")
    node_center.append(center_g)
    data_matrix.append(data.iloc[center_g_index,])
    #data_matrix_array = np.array(data_matrix)
    #print("data_matrix_array.shape", data_matrix_array.shape)    #(gene number,30)
    nodes_nei.append(nei_g)
f.close()

path0 = './CVP-main/TCGA'
path0 = '.' + os.sep
path_name = 'data_LUAD.txt'
path = path0 + path_name

data_new = np.array(data_matrix).T
print("data_new.shape", data_new.shape)    #(30,1472)
data_new = np.log(data_new + 1)

# 训练样本和测试样本
train = data_new[0:7, :]         #0:7
test = data_new[7:30, :]         #7:30

gene_name = node_center
nei_list = nodes_nei


def ttr(gene1, gene_1, gn, sample_test):
    if len(gene_1) >= 1:
        erro = []
        k = 0
        y_index = ind([gene1], gn)
        x_index = ind(gene_1, gn)
        reg = LinearRegression().fit(train[:, x_index], train[:, y_index])  # 通过训练集模拟回归模型
        erro_1 = (reg.predict(sample_test[:, x_index]) - sample_test[:, y_index]) ** 2  # 计算测试集的残差平方和
        # erro.append(erro_1)
        erro_avg = erro_1[0][0]
    else:
        erro_avg = 0
    return erro_avg


def regulon(gene1, genenei, sample_test):
    gene2 = genenei
    end = []
    end_1 = [gene1]
    end_2 = [0]
    if len(gene2) >= 2:
        erro_1 = ttr(gene1, gene2, gene_name, sample_test)
        ##########
        gene_b = copy.deepcopy(gene2)
        gene2_len = list(range(len(gene2)))
        for j in gene2_len:
            gene_b.remove(gene2[j])
            erro_2 = ttr(gene1, gene_b, gene_name, sample_test)
            erro_j = erro_1 - erro_2
            if erro_j < 0:
                gene_b.append(gene2[j])
                end_1.append(gene2[j])
                end_2.append(erro_j)
            else:
                erro_1 = erro_2
        end.append([end_1, end_2])
    else:
        end.append([end_1, end_2])
    return end


def pairs1(filename):
    data = montage(filename)
    gstr = [data[i][0:int(len(data[i]) / 2)] for i in range(len(data))]
    rdata = [data[i][int(len(data[i]) / 2) + 1:len(data[i])] for i in range(len(data))]
    rdata = [list(map(float, rdata[i])) for i in range(len(rdata))]
    z = np.concatenate((rdata), axis=0)
    z_tho = 0
    g = []
    g0 = []
    for i in range(len(gstr)):
        gstr0 = [gstr[i][0]]
        for j in range(len(rdata[i])):
            if abs(rdata[i][j]) > z_tho:
                gstr0.append(gstr[i][j + 1])
                gname = [gstr[i][j + 1], gstr[i][0], -rdata[i][j]]
                g0.append(gname)
        if len(gstr0) > 1:
            g.append(gstr0)
    return g0

es = 0.00000000001

# 定义正态分布的 PDF 函数
def normal_pdf(t, mean_i, std_dev_i):
    return (1 / (np.sqrt(2 * np.pi * std_dev_i ** 2))) * np.exp(
        -((t - mean_i) ** 2) / (2 * std_dev_i ** 2)
    )

# 定义积分函数来计算 CDF
def calculate_cdf(x_ij, mean_i, std_dev_i):
    # 积分 PDF 函数从 -∞ 到 x_ij
    result, _ = quad(normal_pdf, -np.inf, x_ij, args=(mean_i, std_dev_i))
    return result


def calculate_gene_probabilities(train,sample_test):
    for ii in range(len(test)):
        sample_test = test[ii:ii + 1, :]
        # 初始化存储每个 sample 的总熵值的列表
        train_and_test = np.vstack((train, sample_test))  # (51, 1805)
        print("train_and_test.shape:", train_and_test.shape)
        # 计算每个基因在所有样本中的均值和标准偏差
        means = np.mean(train_and_test, axis=0)  # (1805,)
        std_devs_1 = np.std(train_and_test, axis=0)  # (1805,)
        std_devs = std_devs_1 + es  # 添加一个小的常数 es 避免除以零
        # 初始化存储每个基因在每个样本中概率的列表
        gene_probabilities = []
        # 遍历每个基因
        for i in range(train_and_test.shape[1]):  # train_and_test.shape[1] 是基因的数量 1805
            gene_probabilities_for_gene = []
            cdf_values_for_gene = []
            # 获取当前基因在所有样本中的表达数据
            gene_expression_data = train_and_test[:, i]  # (51,)
            # 计算当前基因的概率密度函数和累积分布函数
            for x_ij in gene_expression_data:
                pdf_ij = normal_pdf(x_ij, means[i], std_devs[i])
                gene_probabilities_for_gene.append(pdf_ij)
                # 计算累积分布函数
                cdf_ij = calculate_cdf(x_ij, means[i], std_devs[i])
                cdf_values_for_gene.append(cdf_ij)
            # 归一化累积概率以得到节点概率
            node_probabilities_for_gene = np.array(cdf_values_for_gene) / np.sum(cdf_values_for_gene)
            gene_probabilities.append(node_probabilities_for_gene)
            #print("gene_probabilities",gene_probabilities)
        return gene_probabilities

def re(train,sample_test, gene_name, predict_pairs1):
    start_time = timer()
    train_and_test = np.vstack((train, sample_test))
    # train: 50sample*1805gene   # sample_test: 1sample*1805gene   # train_and_test: 50sample*1805gene
    external_sample_entropy = []               #SCNE_11.29(1)
    #external_entropy = []       #################
    indeed_local_entropy_1 = []
    external_sample_list = []
    S = []
    for i in range(len(gene_name)):
        g = gene_name[i]
        print("g:",g)
        indeed_result_erro = []
        indeed_entropy = []
        for j in range(len(predict_pairs1)):
            predict_list = predict_pairs1[j]
            # print(predict_list)
            if g in predict_list:
                g_index = predict_list.index(g)
                if g_index == 1:
                    indeed_result_erro.append(predict_list[2])  # indeed_result_erro
                    #print("indeed_result_erro",indeed_result_erro)
                    n = len(train_and_test[:, 0])  # sample  number
                    c = gene_name.index(predict_list[0])
                    center_gene_index = gene_name.index(predict_list[1])
                    # for m in range(n):
                    #     indeed_exp_T.append(train_and_test[m][c])  # indeed_exp_T    ####-------------
                else:
                    out = gene_name.index(predict_list[1])
        if indeed_result_erro == []:
            external_entropy = 0        #####----------  indeed_local_entropy = 0
            print("external_entropy = 0")
        else:
            in_list = np.array([(x / sum(indeed_result_erro)) for x in indeed_result_erro])  # in_list
            (gene_probabilities) = calculate_gene_probabilities(train,sample_test)  # calculate_gene_probabilities
            gene_probabilities_list = gene_probabilities[c]
            gene_probabilities_list_center = gene_probabilities[center_gene_index]
            external_entropy = 0
            for l in range(n):  # sample  number
                joint_p = gene_probabilities_list[l] * in_list
                b1_p = gene_probabilities_list[l]
                b2_p = gene_probabilities_list_center[l]
                indeed_local_entropy_1 = train_and_test[l][center_gene_index] * joint_p       #---------c----center_gene_index
                external_entropy += np.dot(indeed_local_entropy_1, np.log(joint_p.T / (b1_p * b2_p + es)))  #-------es
                #print("external_entropy:",external_entropy)
        external_sample_entropy.append(external_entropy)
        print("len(external_sample_entropy):",len(external_sample_entropy))
        #S.append(external_sample_entropy)
        #print("S:",S)
        #external_sample_list.append(external_sample_entropy)
        #external_sample_list_1 = copy.deepcopy(external_sample_entropy)
    end_time = timer()
    Total_time = end_time - start_time
    print(f'循环运行的总时间为：{Total_time}')
    return external_sample_entropy




if __name__ == "__main__":
    external_entropy_matrix = []
    #for ii in range(len(test)):
    for ii in range(11,12):
        print(f'第{ii}轮-----------------')
        sample_test = test[ii:ii + 1, :]
        rt = []
        k = 0;
        start_time = timer()
        for circle, i in enumerate(gene_name):
            print(f'第{circle}轮，基因名为：{i}')
            gene_nei = nei_list[k]
            k = k + 1
            mygene = gene_nei
            regu = regulon(i, mygene, sample_test)
            rt.append(regu)
        end_time = timer()
        Total_time = end_time - start_time
        print(f'第{ii}轮循环运行的总时间为：{Total_time}')
        text_save(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt', rt)
        f = codecs.open(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt', mode='r', encoding='utf-8')
        line = f.readline()
        targets = []
        regulators = []
        while line:
            a = line.split()
            b = a[0:1]
            b1 = a[0:int(len(a) / 2)]
            targets.append(b[0])
            regulators.append(b1)
            line = f.readline()
        f.close()
        filename = path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt'
        predict_pairs1 = pairs1(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt')
        external_sample_entropy  = re(train, sample_test, gene_name,predict_pairs1)
        print("external_sample_entropy:",external_sample_entropy)
        external_entropy_matrix.append(external_sample_entropy)
        os.remove(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt')

external_entropy_matrix_data = np.array(external_entropy_matrix).T
external_entropy_matrix_result = pd.DataFrame(data=external_entropy_matrix_data)
external_entropy_matrix_result.to_csv('CENFE_all_samples.csv')

