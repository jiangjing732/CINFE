import pandas as pd
import numpy as np
import os
import copy
import math
import codecs
from timeit import default_timer as timer
from scipy.stats import norm
from scipy.integrate import  quad

data = pd.read_csv('express_matrix.csv', sep=',', header=None, index_col=0)
all_gene = list(data.index)
data1 = data.T

#1.sample_text
f = open('network.txt')
node_center = []
nodes_nei = []
data_matrix = []

while True:
    line = f.readline()
    if len(line) == 0:
        break
    # 去除行尾的换行符并分割字段，同时去除空白字符
    fields = [field.strip() for field in line.rstrip().split('\t')]
    # 检查是否有空字符串字段
    if '' in fields:
        print(f"Line contains empty fields: {line}")
        continue
    try:
        center_g_index = int(fields[0]) - 1
        center_g = all_gene[center_g_index]
    except ValueError:
        print(f"Invalid center gene identifier on line: {line}")
        continue
    nei_g = []
    for g in range(1, len(fields) - 1):
        gene_str = fields[g]
        if gene_str:  # 确保基因标识符不为空或只包含空白字符
            try:
                gene_index = int(gene_str) - 1
                nei_g.append(all_gene[gene_index])
            except ValueError:
                print(f"Invalid neighbor gene identifier '{gene_str}' on line: {line}")
        else:
            print(f"Empty neighbor gene identifier at position {g + 1} on line: {line}")
    # 处理最后一个字段，去除可能的尾随字符
    last_field = fields[-1].strip()
    if last_field:
        try:
            last_gene_index = int(last_field) - 1
            nei_g.append(all_gene[last_gene_index])
        except ValueError:
            print(f"Invalid last gene identifier '{last_field}' on line: {line}")
    else:
        print(f"Empty last gene identifier on line: {line}")
    node_center.append(center_g)
    data_matrix.append(data.iloc[center_g_index,])  #----------------
    nodes_nei.append(nei_g)
f.close()

data_new = np.array(data_matrix).T
data_new = np.log(data_new + 1)     #----------------------
#data_new = (data_new - np.mean(data_new))/np.std(data_new) #----------------------12.14

# 训练样本和测试样本
train = data_new[0:7, :]            #---------------0:7
test = data_new[7:30, :]            #---------------7:30
# sample_test = test[0:0 + 1, :]

# 2.gene_name
gene_name = node_center

# 3.predict_pairs1
def text(file_name):
    with open(file_name, 'r+') as f:
        line = f.readline()
        while line:
            yield line.split()
            line = f.readline()
def montage(file_name):
    a = []
    for i in text(file_name):
        a.append(i)
    return a
def  pairs1(filename):
	data=montage(filename)
	gstr=[data[i][0:int(len(data[i])/2)] for i in range(len(data))]
	rdata=[data[i][int(len(data[i])/2)+1:len(data[i])] for i in range(len(data))]
	rdata= [list(map(float, rdata[i])) for i in range(len(rdata))]
	z=np.concatenate((rdata), axis=0)
	z_tho=0
	g=[]
	g0=[]
	for i in range(len(gstr)):
		gstr0=[gstr[i][0]]
		for j in range(len(rdata[i])):
			if abs(rdata[i][j])>z_tho:
				gstr0.append(gstr[i][j+1])
				gname=[gstr[i][j+1],gstr[i][0],-rdata[i][j]]
				g0.append(gname)
		if len(gstr0)>1:
			g.append(gstr0)
	return g0

path0 = './CVP-main/TCGA'
path0 = '.' + os.sep
path_name = 'data_LUAD.txt'
path = path0 + path_name

# 检查路径是否存在
if os.path.exists(path):
    print("路径存在。")
else:
    print("路径不存在。")

def text_save(filename, data):
    file = open(filename, 'w')
    for i in range(len(data)):
        s = str(data[i]).replace('[', '').replace(']', '')
        s = s.replace("'", '').replace(',', '') + '\n'
        file.write(s)
    file.close()

# 在另一个程序中读取列表
# with open('rt.txt', 'r') as f:
#     rt = [line.strip() for line in f]


#text_save(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt', rt)
f = codecs.open(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt', mode='r', encoding='utf-8')
line = f.readline()
targets = []
regulators = []
while line:
    a = line.split()
    b = a[0:1]
    b1 = a[0:int(len(a) / 2)]
    targets.append(b[0])
    regulators.append(b1)
    line = f.readline()
f.close()

predict_pairs1 = pairs1(path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt')
#path0 + path_name[0][0:-4] + '_LUAD_pcc0_r.txt'  :  "rt"   format  conversion

# run
es = 0.00000000001
# 定义正态分布的 PDF 函数
def normal_pdf(t, mean_i, std_dev_i):
    return (1 / (np.sqrt(2 * np.pi * std_dev_i ** 2))) * np.exp(
        -((t - mean_i) ** 2) / (2 * std_dev_i ** 2)
    )

# 定义积分函数来计算 CDF
def calculate_cdf(x_ij, mean_i, std_dev_i):
    # 积分 PDF 函数从 -∞ 到 x_ij
    result, _ = quad(normal_pdf, -np.inf, x_ij, args=(mean_i, std_dev_i))
    return result

#def calculate_gene_probabilities(train,sample_test):
total_entropies_all_samples = []
for ii in range(len(test)):
    sample_test = test[ii:ii + 1, :]
    # 初始化存储每个 sample 的总熵值的列表
    #total_entropies_all_samples = []
    train_and_test = np.vstack((train, sample_test))  # (51, 1805)
    print("train_and_test.shape:", train_and_test.shape)
    # 计算每个基因在所有样本中的均值和标准偏差
    means = np.mean(train_and_test, axis=0)  # (1805,)
    std_devs_1 = np.std(train_and_test, axis=0)  # (1805,)
    std_devs = std_devs_1 + es  # 添加一个小的常数 es 避免除以零
    # 初始化存储每个基因在每个样本中概率的列表
    gene_probabilities = []
    total_entropies = []
    # 遍历每个基因
    for i in range(train_and_test.shape[1]):  # train_and_test.shape[1] 是基因的数量 1805
        gene_probabilities_for_gene = []
        cdf_values_for_gene = []
        # 获取当前基因在所有样本中的表达数据
        gene_expression_data = train_and_test[:, i]  # (51,)
        # 计算当前基因的概率密度函数和累积分布函数
        for x_ij in gene_expression_data:
            pdf_ij = normal_pdf(x_ij, means[i], std_devs[i])
            gene_probabilities_for_gene.append(pdf_ij)
            # 计算累积分布函数
            cdf_ij = calculate_cdf(x_ij, means[i], std_devs[i])
            cdf_values_for_gene.append(cdf_ij)
        # 归一化累积概率以得到节点概率
        node_probabilities_for_gene = np.array(cdf_values_for_gene) / np.sum(cdf_values_for_gene)
        gene_probabilities.append(node_probabilities_for_gene)
        # 计算每个样本的基因表达值乘以对应的节点概率
        weighted_expression = gene_expression_data * node_probabilities_for_gene

        # 将列表转换为 NumPy 数组以便进行向量化操作
        entropy_matrix = np.array(weighted_expression)
        # # 计算最小值和最大值
        min_value = np.min(entropy_matrix)
        max_value = np.max(entropy_matrix)
        # # 进行最小-最大标准化
        weighted_expression = (entropy_matrix - min_value) / (max_value - min_value)

        # 计算每个样本的基因表达值乘以对应的节点概率的自然对数
        log_expression = np.log(weighted_expression + es)
        # 计算总熵
        total_entropy = -np.sum(weighted_expression * log_expression)
        total_entropies.append(total_entropy)
    total_entropies_all_samples.append((total_entropies))

    total_entropies_all_samples_1 = np.array(total_entropies_all_samples).T
    total_entropies_all_samples_2 = pd.DataFrame(data=np.array(total_entropies_all_samples_1))
    total_entropies_all_samples_2.to_csv('CTNFE_all_samples.csv', index=False)

    #return (gene_probabilities,total_entropies_all_samples)
