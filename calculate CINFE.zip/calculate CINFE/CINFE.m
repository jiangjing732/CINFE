clear;
clc;
close all;
totalentropy = readtable('CTNFE_all_samples.csv');
externalentropy = readtable('CENFE_all_samples.csv');

totalentropy = totalentropy(2:end,:);
externalentropy = externalentropy(2:end,:);

genename = readtable('express_matrix.csv');
genename.Properties.VariableNames{1} = 'GeneName';

% 计算 CINFE 
CINFE_Score = totalentropy - externalentropy;
data_entropy = CINFE_Score


anyIsMissing = ismissing(data_entropy);
allIsEmpty = all(isempty(data_entropy), 2);
filtered_data_entropy = data_entropy(~allIsEmpty, :);


pnum=[1,7,8,7];
data_entropy_size=size(data_entropy);
n=1;
for t=1:length(pnum)                                          
    count=0;                                                  
    for c=n:sum(pnum(1:t))                                    
        count=count+1;    
        p = floor(data_entropy_size(1)*0.2);                  
        all_tmp_entropies{t, count} = data_entropy(:, c);     
        tmp_entropy=sortrows(data_entropy(:,c));              
        tmp_entropy = flipud(tmp_entropy);
        
        all_tmp_entropies_sort{t, count} = tmp_entropy(1:p, :); 
        aver_entropy(t,count)=mean(tmp_entropy(1:p,:));    
    end
    selected_columns = aver_entropy(t, 1:pnum(t)); 
    case_result(t) = mean(selected_columns{:, :});  
    n=1+sum(pnum(1:t));
end

combined_rows = cell(4, 1);


for i = 1:4
    
    row_tables = all_tmp_entropies(i, :);
    combined_table = row_tables{1};
    for j = 2:8
        combined_table = [combined_table, row_tables{j}];
    end
    combined_rows{i} = combined_table;
end


combined_rows1 = combined_rows{1,1};
combined_rows2 = combined_rows{2,1};
combined_rows3 = combined_rows{3,1};
combined_rows4 = combined_rows{4,1};


row_means1 = table2array(combined_rows1);
row_means1 = row_means1(1:p,:);

combined_rows2 = table2array(combined_rows2);
row_means2 = zeros(p, 1);
for i = 1:p
    row_means2(i) = mean(combined_rows2(i, :));
end


combined_rows3 = table2array(combined_rows3);
row_means3 = zeros(p, 1);
for i = 1:p
    row_means3(i) = mean(combined_rows3(i, :));
end


combined_rows4 = table2array(combined_rows4);
row_means4 = zeros(p, 1);
for i = 1:p
    row_means4(i) = mean(combined_rows4(i, :));
end

combined_row_means = [row_means1, row_means2, row_means3, row_means4];


plot(1:4,case_result,'r-*','LineWidth',3);
max_value = max(case_result);
min_value = min(case_result);
ylim([min_value-0.01 max_value+0.01])
xlabel('Stage');  
ylabel('CINFE Score');  
xticks(1:4); 
xticklabels({'I', 'II', 'III', 'IV'});  
title('Casual internal network flow entropy of AD');  



